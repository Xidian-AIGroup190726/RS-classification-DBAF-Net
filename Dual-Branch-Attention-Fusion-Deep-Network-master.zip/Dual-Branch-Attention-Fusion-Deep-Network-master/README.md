# Dual-Branch-Attention-Fusion-Deep-Network (DBAF-Net) 
This is a Dual-Branch-Attention-Fusion-Deep-Network (DBAF-Net) structure demoe for  Multiresolution Remote-Sensing Image Classification.
This network comes from the paper "A Dual-Branch Attention Fusion Deep Network for Multiresolution Remote-Sensing Image Classification" (under review).
